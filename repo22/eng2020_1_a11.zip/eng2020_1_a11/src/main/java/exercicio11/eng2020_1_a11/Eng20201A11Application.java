package exercicio11.eng2020_1_a11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eng20201A11Application {

	public static void main(String[] args) {
		SpringApplication.run(Eng20201A11Application.class, args);
	}

}
