package exercicio11.eng2020_1_a11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eng20201A11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
